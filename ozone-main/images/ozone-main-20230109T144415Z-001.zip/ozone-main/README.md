# ozone

This is a project for Science India Fest(scienceindiafest.org). This project is to make a visualization of the Ozone layer around earth and the values of its concentration around the globe.

We're live at : https://vectronxel.github.io/ozone/

Repository---------------------->>> live website
part 1----tesla copy
part 2- globe
part 3-air pollution 
part 4 - portfolio of all
part 5-documentation section
link all 
Generate qr code at last 
Including apk

